An example of a modern Todo web application built using Java with Spring Boot, Javascript with VueJS and NuxtJS, Docker, Railway, and GitHub Actions.
