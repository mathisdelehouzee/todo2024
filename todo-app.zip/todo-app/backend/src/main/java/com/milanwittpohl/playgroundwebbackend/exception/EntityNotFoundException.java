package com.milanwittpohl.playgroundwebbackend.exception;

public class EntityNotFoundException extends RuntimeException {}